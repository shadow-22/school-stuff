/**********************************************************************************************/
/* Created by Yannis Kerasiotis, Manos Papalexandrakis, Dinos Tsopelas, Vaggelis Raftopoulos  */
/*                                                                                            */
/* Course: Programming Language 2                                                             */
/* First Series of Exercises                                                                  */
/*                                                                                            */
/* Purpose of this program is generating testcases for second exercise.                       */
/**********************************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char **argv)
{
	FILE *fp;
	
	int N,M, flagS, flagE, i, j, k;
	time_t t;
	
	fp = fopen("testcase.txt","w+");
	
	if (fp == NULL){
		printf("Error!");
		exit (1);
		}
	
	srand((unsigned) time(&t));
	
	flagS=0;
	flagE=0;
	
	N= (rand() % 51) + 4; // N belongs [4,54]
	M= (rand() % 51) + 4; // M belongs [4,54]
	
	for (i=0; i < N; i++) {
		for (j=0; j<M; j++){
			
			do{
				k=rand()%101;
			}while ((k<5 && flagS==1)||(k>=5 && k<10 && flagE==1));
			
			if (k<5 && flagS==0){ // 5% possibility of "S"
				fprintf(fp,"S");
				flagS=1;
				}
			else if  (k<10 && k>=5 && flagE==0){ // 5% possibility of "E"
				fprintf(fp,"E");
				flagE=1;
				}
			else if ( k>=10 && k<20){ // 10% possibility of "X"
				fprintf(fp,"X");
				}
			else if (k>=20 && k<30){ // 10% possibility of "W"
				fprintf (fp,"W");
				}
			else{ // 70% possibility of "."
				fprintf (fp,"."); 
				}
			}
		
		fprintf(fp,"\n");
		
		} 
	
	fclose(fp);
	
	return 0;
}

