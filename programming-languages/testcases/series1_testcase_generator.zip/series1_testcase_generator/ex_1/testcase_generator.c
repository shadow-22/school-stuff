/**********************************************************************************************/
/* Created by Yannis Kerasiotis, Manos Papalexandrakis, Dinos Tsopelas, Vaggelis Raftopoulos  */
/*                                                                                            */
/* Course: Programming Language 1                                                             */
/* First Series of Exercises                                                                  */
/*                                                                                            */
/* Purpose of this program is generating testcases for first exercise.                        */
/**********************************************************************************************/



#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main (){
	
	FILE *fp;
	
	int N,i;
	time_t t;
	
	fp = fopen("testcase.txt","w+");
	
	if (fp == NULL){
		printf("Error!");
		exit (1);
		}
	
	srand((unsigned) time(&t));
	
	N = ( rand() % 9 ) + 2; // Ν belongs [2,10]
	fprintf (fp, "%d\n", N);
	
	for (i=0; i<N; i++){
		
		fprintf(fp, "%d ", rand() % 100 ); // Yi belongs [0,100)
		
		}
	 
	 
	fclose(fp);
	return (0);
	}
